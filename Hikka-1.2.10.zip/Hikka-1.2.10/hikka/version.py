"""Represents current userbot version"""
__version__ = (1, 2, 10)
